# [BehaviorSystem](BehaviorSystem.hpp)

`System` that executes the [BehaviorComponents](../components/BehaviorComponent.md) of `GameObjects`.
