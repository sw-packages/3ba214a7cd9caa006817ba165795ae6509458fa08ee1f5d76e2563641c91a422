# [ImGuiAdjustableManager](ImGuiAdjustableManager.hpp)

`Entity` that renders all the other `Entities` with `AdjustableComponents` in an `ImGui` window.

### Usage

```cpp
em += ImGuiAdjustableManager(em);
```
